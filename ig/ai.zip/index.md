# Home - Asia-Pacific Patient Summary v0.1.0

* [**Table of Contents**](toc.md)
* **Home**

## Home

| | |
| :--- | :--- |
| *Official URL*:https://cylab-tw.github.io/aps-ig/ImplementationGuide/hl7.fhir.asia.aps | *Version*:0.1.0 |
| Draft as of 2026-04-25 | *Computable Name*:AsiaPacificPatientSummaryIg |
| **Copyright/Legal**: Used by permission of Asia-Pacific Patient Summary Alliance, all rights reserved Creative Commons License | |

# Asia-Pacific Patient Summary

This Implementation Guide adapts Asia-Pacific Patient Summary website content into a FHIR IG structure aligned with the style used by IPS and IHE technical frameworks.

## Goal

Support practical, profile-driven cross-border interoperability across the Asia-Pacific region using HL7 FHIR IPS and IHE transaction patterns.

## Asia-Pacific Patient Summary Lifecycle

![](overview.png)

![](lifecycle.png)

## Getting Started

* Read [Introduction](introduction.md)
* Review [Volume 1](volume1-actors-transactions.md) for actors and options
* Review [Volume 2](volume2-iti-65.md) for transaction and API behavior
* Review [Volume 3](volume3-capability-statements.md) for capability, terminology, and examples

## Reference Profiles

* [Patient Demographics Profile (IPD)](profile-ipd.md)
* [International Patient Summary Exchange Profile (IPSE)](profile-ipse.md)
* [IPS Digital Health Wallet Profile (IPS-DHW)](profile-ips-dhw.md)

